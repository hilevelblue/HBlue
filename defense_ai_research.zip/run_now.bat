@echo off
chcp 65001 > nul
echo.
echo  ========================================
echo   국방 군수 AI 연구 - 리포트 즉시 생성
echo  ========================================
echo.
powershell.exe -ExecutionPolicy Bypass -NonInteractive -File "%~dp0main.ps1"
echo.
pause
