﻿﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Windows 작업 스케줄러에 일일 리포트 작업을 등록합니다.

.DESCRIPTION
    config.json의 schedule_time을 읽어 매일 해당 시각에
    main.ps1 이 자동 실행되도록 작업 스케줄러에 등록합니다.
    (관리자 권한 없이도 현재 사용자 계정으로 등록 가능합니다.)

.EXAMPLE
    PowerShell에서 실행:
    powershell -ExecutionPolicy Bypass -File "C:\defense_ai_research\setup_scheduler.ps1"
#>

$configPath  = Join-Path $PSScriptRoot "config.json"
$scriptPath  = Join-Path $PSScriptRoot "main.ps1"
$config      = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$taskName    = "DefenseAI_DailyReport"
$scheduleTime = $config.schedule_time   # 예: "09:00"

Write-Host ""
Write-Host ("=" * 56) -ForegroundColor Cyan
Write-Host "  국방 AI 연구 - 일일 스케줄러 등록" -ForegroundColor Cyan
Write-Host ("=" * 56) -ForegroundColor Cyan
Write-Host ""
Write-Host "  작업 이름  : $taskName"
Write-Host "  실행 시각  : 매일 $scheduleTime"
Write-Host "  스크립트   : $scriptPath"
Write-Host "  리포트 저장: $($config.report_directory)"
Write-Host ""

# 실행 파라미터 확인
if (-not (Test-Path $scriptPath)) {
    Write-Error "main.ps1 을 찾을 수 없습니다: $scriptPath"
    exit 1
}

try {
    # ── 기존 작업 삭제 ───────────────────────────────────────────
    $existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($existing) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        Write-Host "  기존 작업 삭제됨" -ForegroundColor Yellow
    }

    # ── 트리거 (매일 지정 시각) ──────────────────────────────────
    $trigger = New-ScheduledTaskTrigger -Daily -At $scheduleTime

    # ── 실행 명령 ────────────────────────────────────────────────
    $action = New-ScheduledTaskAction `
        -Execute  "powershell.exe" `
        -Argument "-NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$scriptPath`""

    # ── 실행 계정 (현재 사용자, 로그인 시만 실행) ─────────────────
    $principal = New-ScheduledTaskPrincipal `
        -UserId   $env:USERNAME `
        -LogonType Interactive `
        -RunLevel Highest

    # ── 설정 ─────────────────────────────────────────────────────
    $settings = New-ScheduledTaskSettingsSet `
        -ExecutionTimeLimit  (New-TimeSpan -Hours 2) `
        -RestartCount        2 `
        -RestartInterval     (New-TimeSpan -Minutes 10) `
        -MultipleInstances   IgnoreNew `
        -StartWhenAvailable                          # 놓친 실행 자동 처리

    # ── 등록 ─────────────────────────────────────────────────────
    Register-ScheduledTask `
        -TaskName   $taskName `
        -Description "국방 군수 AI 활용 방안 연구 - 일일 리포트 자동 생성" `
        -Action     $action `
        -Trigger    $trigger `
        -Principal  $principal `
        -Settings   $settings | Out-Null

    Write-Host "  등록 완료!" -ForegroundColor Green
    Write-Host ""
    Write-Host "━━━ 관리 방법 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
    Write-Host "  즉시 테스트 실행:"
    Write-Host "    Start-ScheduledTask -TaskName '$taskName'" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  작업 스케줄러 GUI 열기:"
    Write-Host "    taskschd.msc" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  실행 시간 변경 방법:"
    Write-Host "    1. config.json 의 schedule_time 수정" -ForegroundColor Gray
    Write-Host "    2. 이 스크립트를 다시 실행" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  작업 삭제:"
    Write-Host "    Unregister-ScheduledTask -TaskName '$taskName' -Confirm:`$false" -ForegroundColor Yellow
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
    Write-Host ""
}
catch {
    Write-Error "스케줄러 등록 실패: $_"
    Write-Host ""
    Write-Host "권한 문제인 경우 PowerShell을 '관리자 권한으로 실행' 후 다시 시도하세요." -ForegroundColor Yellow
    exit 1
}
