@echo off
chcp 65001 > nul
echo.
echo  ========================================
echo   Windows 작업 스케줄러 등록
echo  ========================================
echo.
powershell.exe -ExecutionPolicy Bypass -File "%~dp0setup_scheduler.ps1"
echo.
pause
