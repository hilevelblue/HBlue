﻿#Requires -Version 5.1
# export.ps1 - Word(.docx) / PowerPoint(.pptx) / HWP(.hwp) 내보내기 함수 모음

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

# ─────────────────────────────────────────────────────────────
# 공통 유틸리티
# ─────────────────────────────────────────────────────────────
function ConvertTo-XmlText([string]$t) {
    if ([string]::IsNullOrEmpty($t)) { return "" }
    $t = $t -replace '&',  '&amp;'
    $t = $t -replace '<',  '&lt;'
    $t = $t -replace '>',  '&gt;'
    $t = $t -replace '"',  '&quot;'
    return $t
}

function New-ZipDocument {
    param([string]$outPath, [hashtable]$files)

    $mem = [System.IO.MemoryStream]::new()
    $zip = [System.IO.Compression.ZipArchive]::new($mem, [System.IO.Compression.ZipArchiveMode]::Create, $true)
    $enc = New-Object System.Text.UTF8Encoding $false   # UTF-8 without BOM

    foreach ($kv in $files.GetEnumerator()) {
        $entry  = $zip.CreateEntry($kv.Key, [System.IO.Compression.CompressionLevel]::Optimal)
        $stream = $entry.Open()
        $bytes  = $enc.GetBytes($kv.Value)
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Close()
    }
    $zip.Dispose()
    [System.IO.File]::WriteAllBytes($outPath, $mem.ToArray())
    $mem.Dispose()
}

# ─────────────────────────────────────────────────────────────
#  WORD 문서 (.docx)
# ─────────────────────────────────────────────────────────────
function Export-Docx {
    param($data, [string]$outPath)

    # ── XML helpers ──────────────────────────────────────────
    function WPara([string]$style, [string]$text, [bool]$bold = $false, [string]$color = "") {
        $t  = ConvertTo-XmlText $text
        $rpr = if ($bold -or $color) {
            $bTag = if ($bold)  { '<w:b/>' }  else { "" }
            $cTag = if ($color) { "<w:color w:val=`"$color`"/>" } else { "" }
            "<w:rPr>$bTag$cTag<w:rFonts w:eastAsia=`"맑은 고딕`"/></w:rPr>"
        } else {
            "<w:rPr><w:rFonts w:eastAsia=`"맑은 고딕`"/></w:rPr>"
        }
        $ppr = if ($style -and $style -ne "Normal") {
            "<w:pPr><w:pStyle w:val=`"$style`"/></w:pPr>"
        } else {
            ""
        }
        return "<w:p>$ppr<w:r>$rpr<w:t xml:space=`"preserve`">$t</w:t></w:r></w:p>"
    }

    function WLabel([string]$label, [string]$val) {
        if ([string]::IsNullOrEmpty($val)) { return "" }
        $l = ConvertTo-XmlText $label
        $v = ConvertTo-XmlText $val
        return "<w:p><w:r><w:rPr><w:b/><w:rFonts w:eastAsia=`"맑은 고딕`"/></w:rPr><w:t xml:space=`"preserve`">$l</w:t></w:r><w:r><w:rPr><w:rFonts w:eastAsia=`"맑은 고딕`"/></w:rPr><w:t xml:space=`"preserve`"> $v</w:t></w:r></w:p>"
    }

    function WTableRow([string[]]$cells) {
        $tds = foreach ($c in $cells) {
            $cv = ConvertTo-XmlText $c
            "<w:tc><w:tcPr><w:tcBorders><w:top w:val=`"single`" w:sz=`"4`"/><w:left w:val=`"single`" w:sz=`"4`"/><w:bottom w:val=`"single`" w:sz=`"4`"/><w:right w:val=`"single`" w:sz=`"4`"/></w:tcBorders></w:tcPr><w:p><w:r><w:rPr><w:rFonts w:eastAsia=`"맑은 고딕`"/></w:rPr><w:t>$cv</w:t></w:r></w:p></w:tc>"
        }
        return "<w:tr>$($tds -join '')</w:tr>"
    }

    # ── Build Body ───────────────────────────────────────────
    $sb = [System.Text.StringBuilder]::new()

    $dateStr = $data.GeneratedAt.ToString("yyyy년 MM월 dd일 HH:mm")

    # 표지
    $sb.AppendLine((WPara "Title"    "국방 군수 AI 활용 방안 연구")) | Out-Null
    $sb.AppendLine((WPara "Subtitle" "일일 리포트  ·  $dateStr"))    | Out-Null
    $sb.AppendLine("<w:p><w:r><w:rPr><w:sz w:val=`"4`"/></w:rPr><w:t> </w:t></w:r></w:p>") | Out-Null

    # ── Section 1: 글로벌 뉴스 ───────────────────────────────
    $sb.AppendLine((WPara "Heading1" "1. 글로벌 뉴스 (Global News)  [$($data.TotalGlobal)건]")) | Out-Null
    foreach ($kw in $data.GlobalNews.Keys) {
        $sb.AppendLine((WPara "Heading2" "검색어: $kw")) | Out-Null
        $i = 1
        foreach ($a in $data.GlobalNews[$kw]) {
            $sb.AppendLine((WPara "Normal" "$i. $($a.Title)" $true "1F3864")) | Out-Null
            $sb.AppendLine((WLabel "출처:"        $a.Source))      | Out-Null
            $sb.AppendLine((WLabel "게재일:"      $a.Published))    | Out-Null
            if ($a['Summary'])   { $sb.AppendLine((WLabel "요약 (원문):" $a['Summary']))   | Out-Null }
            if ($a['SummaryKo']) { $sb.AppendLine((WLabel "요약 (한글):" $a['SummaryKo'])) | Out-Null }
            $sb.AppendLine((WLabel "링크:"        $a.Link))         | Out-Null
            $sb.AppendLine("<w:p/>")                                 | Out-Null
            $i++
        }
    }

    # ── Section 2: 국내 뉴스 ─────────────────────────────────
    $sb.AppendLine((WPara "Heading1" "2. 국내 뉴스 (Korean Domestic News)  [$($data.TotalKr)건]")) | Out-Null
    foreach ($kw in $data.KrNews.Keys) {
        $sb.AppendLine((WPara "Heading2" "검색어: $kw")) | Out-Null
        $i = 1
        foreach ($a in $data.KrNews[$kw]) {
            $sb.AppendLine((WPara "Normal" "$i. $($a.Title)" $true "1F3864")) | Out-Null
            $sb.AppendLine((WLabel "출처:"   $a.Source))    | Out-Null
            $sb.AppendLine((WLabel "게재일:" $a.Published)) | Out-Null
            if ($a.Summary) { $sb.AppendLine((WLabel "요약:" $a.Summary)) | Out-Null }
            $sb.AppendLine((WLabel "링크:"   $a.Link))      | Out-Null
            $sb.AppendLine("<w:p/>")                         | Out-Null
            $i++
        }
    }

    # ── Section 3: 학술 논문 ─────────────────────────────────
    $sb.AppendLine((WPara "Heading1" "3. 최신 학술 논문 (ArXiv)  [$($data.TotalPapers)건]")) | Out-Null
    foreach ($q in $data.Papers.Keys) {
        $sb.AppendLine((WPara "Heading2" "검색어: $q")) | Out-Null
        $i = 1
        foreach ($p in $data.Papers[$q]) {
            $sb.AppendLine((WPara "Normal" "$i. $($p.Title)" $true "1F3864")) | Out-Null
            $sb.AppendLine((WLabel "저자:"        $p.Authors))     | Out-Null
            $sb.AppendLine((WLabel "게재일:"      $p.Published))   | Out-Null
            if ($p['Summary'])   { $sb.AppendLine((WLabel "초록 (원문):" $p['Summary']))   | Out-Null }
            if ($p['SummaryKo']) { $sb.AppendLine((WLabel "초록 (한글):" $p['SummaryKo'])) | Out-Null }
            $sb.AppendLine((WLabel "링크:"        $p.Link))        | Out-Null
            $sb.AppendLine("<w:p/>")                         | Out-Null
            $i++
        }
    }

    # ── Section 4: AI 분석 ───────────────────────────────────
    if (-not [string]::IsNullOrWhiteSpace($data.Analysis)) {
        $sb.AppendLine((WPara "Heading1" "4. AI 분석 요약 (Claude Opus 분석)")) | Out-Null
        foreach ($line in ($data.Analysis -split "`n")) {
            $trimmed = $line.Trim()
            if ($trimmed.StartsWith("### ")) {
                $sb.AppendLine((WPara "Heading3" $trimmed.Substring(4)))    | Out-Null
            } elseif ($trimmed.StartsWith("## ")) {
                $sb.AppendLine((WPara "Heading2" $trimmed.Substring(3)))    | Out-Null
            } elseif ($trimmed.StartsWith("- ")) {
                $sb.AppendLine((WPara "ListParagraph" $trimmed.Substring(2))) | Out-Null
            } elseif ($trimmed) {
                $sb.AppendLine((WPara "Normal" $trimmed)) | Out-Null
            }
        }
    }

    # ── Section 5: 통계 테이블 ──────────────────────────────
    $sb.AppendLine((WPara "Heading1" "5. 수집 통계")) | Out-Null
    $tblXml  = "<w:tbl><w:tblPr><w:tblStyle w:val=`"TableGrid`"/><w:tblW w:w=`"5000`" w:type=`"pct`"/></w:tblPr><w:tblGrid><w:gridCol w:w=`"4000`"/><w:gridCol w:w=`"2000`"/></w:tblGrid>"
    $tblXml += WTableRow @("항목", "건수")
    $tblXml += WTableRow @("글로벌 뉴스 기사",    "$($data.TotalGlobal)건")
    $tblXml += WTableRow @("국내 뉴스 기사",      "$($data.TotalKr)건")
    $tblXml += WTableRow @("학술 논문",           "$($data.TotalPapers)건")
    $tblXml += WTableRow @("글로벌 검색 키워드",  "$($data.GlobalNews.Keys.Count)개")
    $tblXml += WTableRow @("국내 검색 키워드",    "$($data.KrNews.Keys.Count)개")
    $tblXml += WTableRow @("ArXiv 검색 쿼리",     "$($data.Papers.Keys.Count)개")
    $tblXml += "</w:tbl>"
    $sb.AppendLine($tblXml) | Out-Null
    $sb.AppendLine("<w:p/>") | Out-Null
    $sb.AppendLine((WPara "Normal" "* 본 리포트는 자동 생성되었습니다. 생성: $dateStr")) | Out-Null

    # ── Assemble document.xml ────────────────────────────────
    $nsW   = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    $nsMC  = 'xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"'
    $docXml = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>"
    $docXml += "<w:document $nsW $nsMC>"
    $docXml += "<w:body>$($sb.ToString())<w:sectPr><w:pgMar w:top=`"1134`" w:right=`"850`" w:bottom=`"1134`" w:left=`"1418`"/></w:sectPr></w:body>"
    $docXml += "</w:document>"

    # ── Styles ───────────────────────────────────────────────
    $stylesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault><w:rPr>
      <w:rFonts w:ascii="맑은 고딕" w:hAnsi="맑은 고딕" w:eastAsia="맑은 고딕"/>
      <w:sz w:val="20"/><w:lang w:eastAsia="ko-KR"/>
    </w:rPr></w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Normal"><w:name w:val="Normal"/>
    <w:rPr><w:rFonts w:eastAsia="맑은 고딕"/><w:sz w:val="20"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/>
    <w:pPr><w:jc w:val="center"/><w:spacing w:before="480" w:after="120"/></w:pPr>
    <w:rPr><w:rFonts w:ascii="맑은 고딕" w:eastAsia="맑은 고딕"/><w:b/><w:sz w:val="52"/><w:color w:val="1F3864"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/>
    <w:pPr><w:jc w:val="center"/><w:spacing w:before="0" w:after="480"/></w:pPr>
    <w:rPr><w:rFonts w:ascii="맑은 고딕" w:eastAsia="맑은 고딕"/><w:sz w:val="24"/><w:color w:val="595959"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/>
    <w:pPr><w:spacing w:before="360" w:after="120"/><w:outlineLvl w:val="0"/>
      <w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="1F3864"/></w:pBdr>
    </w:pPr>
    <w:rPr><w:rFonts w:ascii="맑은 고딕" w:eastAsia="맑은 고딕"/><w:b/><w:sz w:val="28"/><w:color w:val="1F3864"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/>
    <w:pPr><w:spacing w:before="240" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr>
    <w:rPr><w:rFonts w:ascii="맑은 고딕" w:eastAsia="맑은 고딕"/><w:b/><w:sz w:val="24"/><w:color w:val="2E74B5"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/>
    <w:pPr><w:spacing w:before="160" w:after="60"/><w:outlineLvl w:val="2"/></w:pPr>
    <w:rPr><w:rFonts w:ascii="맑은 고딕" w:eastAsia="맑은 고딕"/><w:b/><w:sz w:val="22"/><w:color w:val="5B9BD5"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/>
    <w:pPr><w:ind w:left="720"/></w:pPr>
    <w:rPr><w:rFonts w:eastAsia="맑은 고딕"/><w:sz w:val="20"/></w:rPr></w:style>
  <w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/>
    <w:tblPr><w:tblBorders>
      <w:top w:val="single" w:sz="4"/><w:left w:val="single" w:sz="4"/>
      <w:bottom w:val="single" w:sz="4"/><w:right w:val="single" w:sz="4"/>
      <w:insideH w:val="single" w:sz="4"/><w:insideV w:val="single" w:sz="4"/>
    </w:tblBorders></w:tblPr></w:style>
</w:styles>
"@

    $created = $data.GeneratedAt.ToString("yyyy-MM-ddTHH:mm:ssZ")
    $coreXml = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><cp:coreProperties xmlns:cp=`"http://schemas.openxmlformats.org/package/2006/metadata/core-properties`" xmlns:dc=`"http://purl.org/dc/elements/1.1/`"><dc:title>국방 군수 AI 활용 방안 연구 - 일일 리포트</dc:title><dc:creator>defense_ai_research</dc:creator><cp:created>$created</cp:created></cp:coreProperties>"
    $appXml  = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Properties xmlns=`"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties`"><Application>defense_ai_research.ps1</Application></Properties>"
    $relsXml = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Relationships xmlns=`"http://schemas.openxmlformats.org/package/2006/relationships`"><Relationship Id=`"rId1`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument`" Target=`"word/document.xml`"/><Relationship Id=`"rId2`" Type=`"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties`" Target=`"docProps/core.xml`"/><Relationship Id=`"rId3`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties`" Target=`"docProps/app.xml`"/></Relationships>"
    $docRels = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Relationships xmlns=`"http://schemas.openxmlformats.org/package/2006/relationships`"><Relationship Id=`"rId1`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles`" Target=`"styles.xml`"/></Relationships>"
    $ctXml   = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Types xmlns=`"http://schemas.openxmlformats.org/package/2006/content-types`"><Default Extension=`"rels`" ContentType=`"application/vnd.openxmlformats-package.relationships+xml`"/><Default Extension=`"xml`" ContentType=`"application/xml`"/><Override PartName=`"/word/document.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml`"/><Override PartName=`"/word/styles.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml`"/><Override PartName=`"/docProps/core.xml`" ContentType=`"application/vnd.openxmlformats-package.core-properties+xml`"/><Override PartName=`"/docProps/app.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.extended-properties+xml`"/></Types>"

    New-ZipDocument -outPath $outPath -files @{
        "[Content_Types].xml"    = $ctXml
        "_rels/.rels"            = $relsXml
        "word/document.xml"      = $docXml
        "word/styles.xml"        = $stylesXml
        "word/_rels/document.xml.rels" = $docRels
        "docProps/core.xml"      = $coreXml
        "docProps/app.xml"       = $appXml
    }
}

# ─────────────────────────────────────────────────────────────
#  POWERPOINT 발표자료 (.pptx)
# ─────────────────────────────────────────────────────────────
function Export-Pptx {
    param($data, [string]$outPath)

    $slides      = [System.Collections.Generic.List[hashtable]]::new()
    $slideCount  = 0

    # ── Slide builder helpers ────────────────────────────────
    function New-SlideXml([string]$title, [string[]]$bodyLines, [string]$bgColor = "1F3864", [string]$titleColor = "FFFFFF", [string]$bodyColor = "FFFFFF") {
        $esc_title = ConvertTo-XmlText $title
        $bodySb    = [System.Text.StringBuilder]::new()
        foreach ($line in $bodyLines) {
            if ([string]::IsNullOrEmpty($line)) { continue }
            $esc_line  = ConvertTo-XmlText $line
            $isBullet  = $esc_line.StartsWith("•") -or $esc_line.StartsWith("-")
            $fontSize  = if ($isBullet) { "1400" } else { "1600" }
            $bold      = if ($esc_line -match "^\d+\.") { "<a:b/>" } else { "" }
            $bodySb.Append("<a:p><a:pPr marL=`"228600`" indent=`"-228600`"/><a:r><a:rPr lang=`"ko-KR`" sz=`"$fontSize`" dirty=`"0`">$bold<a:solidFill><a:srgbClr val=`"$bodyColor`"/></a:solidFill><a:latin typeface=`"맑은 고딕`"/><a:ea typeface=`"맑은 고딕`"/></a:rPr><a:t>$esc_line</a:t></a:r></a:p>") | Out-Null
        }

        return "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>" +
            "<p:sld xmlns:p=`"http://schemas.openxmlformats.org/presentationml/2006/main`" " +
            "xmlns:a=`"http://schemas.openxmlformats.org/drawingml/2006/main`" " +
            "xmlns:r=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships`">" +
            "<p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val=`"$bgColor`"/></a:solidFill></p:bgPr></p:bg>" +
            "<p:spTree>" +
            "<p:nvGrpSpPr><p:cNvPr id=`"1`" name=`"Group`"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
            "<p:grpSpPr><a:xfrm><a:off x=`"0`" y=`"0`"/><a:ext cx=`"0`" cy=`"0`"/><a:chOff x=`"0`" y=`"0`"/><a:chExt cx=`"0`" cy=`"0`"/></a:xfrm></p:grpSpPr>" +
            # Title
            "<p:sp><p:nvSpPr><p:cNvPr id=`"2`" name=`"Title`"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>" +
            "<p:spPr><a:xfrm><a:off x=`"457200`" y=`"274638`"/><a:ext cx=`"8229600`" cy=`"762000`"/></a:xfrm>" +
            "<a:prstGeom prst=`"rect`"><a:avLst/></a:prstGeom></p:spPr>" +
            "<p:txBody><a:bodyPr/><a:lstStyle/>" +
            "<a:p><a:r><a:rPr lang=`"ko-KR`" sz=`"2400`" b=`"1`" dirty=`"0`">" +
            "<a:solidFill><a:srgbClr val=`"$titleColor`"/></a:solidFill>" +
            "<a:latin typeface=`"맑은 고딕`"/><a:ea typeface=`"맑은 고딕`"/></a:rPr>" +
            "<a:t>$esc_title</a:t></a:r></a:p></p:txBody></p:sp>" +
            # Body
            "<p:sp><p:nvSpPr><p:cNvPr id=`"3`" name=`"Body`"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>" +
            "<p:spPr><a:xfrm><a:off x=`"457200`" y=`"1143000`"/><a:ext cx=`"8229600`" cy=`"4720338`"/></a:xfrm>" +
            "<a:prstGeom prst=`"rect`"><a:avLst/></a:prstGeom></p:spPr>" +
            "<p:txBody><a:bodyPr wrap=`"square`" lIns=`"91440`" tIns=`"45720`" rIns=`"91440`" bIns=`"45720`" anchor=`"t`"/>" +
            "<a:lstStyle/>$($bodySb.ToString())</p:txBody></p:sp>" +
            "</p:spTree></p:cSld></p:sld>"
    }

    # ── 슬라이드 1: 표지 ─────────────────────────────────────
    $d = $data.GeneratedAt.ToString("yyyy년 MM월 dd일")
    $titleSlide = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>" +
        "<p:sld xmlns:p=`"http://schemas.openxmlformats.org/presentationml/2006/main`" " +
        "xmlns:a=`"http://schemas.openxmlformats.org/drawingml/2006/main`" " +
        "xmlns:r=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships`">" +
        "<p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val=`"1F3864`"/></a:solidFill></p:bgPr></p:bg>" +
        "<p:spTree><p:nvGrpSpPr><p:cNvPr id=`"1`" name=`"Group`"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x=`"0`" y=`"0`"/><a:ext cx=`"0`" cy=`"0`"/><a:chOff x=`"0`" y=`"0`"/><a:chExt cx=`"0`" cy=`"0`"/></a:xfrm></p:grpSpPr>" +
        "<p:sp><p:nvSpPr><p:cNvPr id=`"2`" name=`"T`"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr>" +
        "<p:spPr><a:xfrm><a:off x=`"457200`" y=`"1219200`"/><a:ext cx=`"8229600`" cy=`"1143000`"/></a:xfrm><a:prstGeom prst=`"rect`"><a:avLst/></a:prstGeom></p:spPr>" +
        "<p:txBody><a:bodyPr anchor=`"ctr`"/><a:lstStyle/>" +
        "<a:p><a:pPr algn=`"ctr`"/><a:r><a:rPr lang=`"ko-KR`" sz=`"3600`" b=`"1`" dirty=`"0`"><a:solidFill><a:srgbClr val=`"FFFFFF`"/></a:solidFill><a:latin typeface=`"맑은 고딕`"/><a:ea typeface=`"맑은 고딕`"/></a:rPr><a:t>국방 군수 AI 활용 방안 연구</a:t></a:r></a:p>" +
        "<a:p><a:pPr algn=`"ctr`"/><a:r><a:rPr lang=`"ko-KR`" sz=`"2000`" dirty=`"0`"><a:solidFill><a:srgbClr val=`"BDD7EE`"/></a:solidFill><a:latin typeface=`"맑은 고딕`"/><a:ea typeface=`"맑은 고딕`"/></a:rPr><a:t>일일 리포트  ·  $d</a:t></a:r></a:p>" +
        "</p:txBody></p:sp></p:spTree></p:cSld></p:sld>"
    $slides.Add(@{ xml = $titleSlide })
    $slideCount++

    # ── 슬라이드 2: 통계 요약 ────────────────────────────────
    $statsLines = @(
        "• 글로벌 뉴스:    $($data.TotalGlobal)건  (키워드 $($data.GlobalNews.Keys.Count)개)",
        "• 국내 뉴스:      $($data.TotalKr)건  (키워드 $($data.KrNews.Keys.Count)개)",
        "• 학술 논문:      $($data.TotalPapers)건  (쿼리 $($data.Papers.Keys.Count)개)",
        "",
        "• 검색 날짜:      $d",
        "• AI 분석 포함:   $(if ([string]::IsNullOrWhiteSpace($data.Analysis)) { 'N/A (API키 미설정)' } else { '포함' })"
    )
    $slides.Add(@{ xml = (New-SlideXml "수집 통계 요약" $statsLines "2E4057" "FFFFFF" "D9E8F5") })
    $slideCount++

    # ── 슬라이드 3~: 글로벌 뉴스 (3개씩) ────────────────────
    $newsBuffer = [System.Collections.Generic.List[string]]::new()
    $slideNum   = 1
    $totalSlides = [Math]::Ceiling($data.TotalGlobal / 3)
    foreach ($kw in $data.GlobalNews.Keys) {
        foreach ($a in $data.GlobalNews[$kw]) {
            $newsBuffer.Add("$(($newsBuffer.Count + 1)). $($a.Title)")
            $newsBuffer.Add("  출처: $($a.Source)  |  날짜: $($a.Published)")
            if ($a.Summary)   { $newsBuffer.Add("  [원문] $($a.Summary.Substring(0,[Math]::Min(100,$a.Summary.Length)))") }
            if ($a.SummaryKo) { $newsBuffer.Add("  [한글] $($a.SummaryKo.Substring(0,[Math]::Min(100,$a.SummaryKo.Length)))") }
            $newsBuffer.Add("")
            if ($newsBuffer.Count -ge 12) {
                $slides.Add(@{ xml = (New-SlideXml "글로벌 뉴스 [$slideNum/$totalSlides]" $newsBuffer.ToArray() "1F3864") })
                $slideCount++
                $newsBuffer.Clear()
                $slideNum++
            }
        }
    }
    if ($newsBuffer.Count -gt 0) {
        $slides.Add(@{ xml = (New-SlideXml "글로벌 뉴스 [$slideNum/$totalSlides]" $newsBuffer.ToArray() "1F3864") })
        $slideCount++
    }

    # ── 국내 뉴스 슬라이드 ───────────────────────────────────
    $krBuffer  = [System.Collections.Generic.List[string]]::new()
    $slideNum  = 1
    $totalKrSl = [Math]::Ceiling($data.TotalKr / 3)
    foreach ($kw in $data.KrNews.Keys) {
        foreach ($a in $data.KrNews[$kw]) {
            $krBuffer.Add("$(($krBuffer.Count + 1)). $($a.Title)")
            $krBuffer.Add("  출처: $($a.Source)  |  날짜: $($a.Published)")
            if ($a.Summary) { $krBuffer.Add("  $($a.Summary.Substring(0,[Math]::Min(120,$a.Summary.Length)))") }
            $krBuffer.Add("")
            if ($krBuffer.Count -ge 12) {
                $slides.Add(@{ xml = (New-SlideXml "국내 뉴스 [$slideNum/$totalKrSl]" $krBuffer.ToArray() "2E4057") })
                $slideCount++
                $krBuffer.Clear()
                $slideNum++
            }
        }
    }
    if ($krBuffer.Count -gt 0) {
        $slides.Add(@{ xml = (New-SlideXml "국내 뉴스 [$slideNum/$totalKrSl]" $krBuffer.ToArray() "2E4057") })
        $slideCount++
    }

    # ── 학술 논문 슬라이드 ──────────────────────────────────
    $paperBuffer = [System.Collections.Generic.List[string]]::new()
    $slideNum    = 1
    $totalPapSl  = [Math]::Ceiling($data.TotalPapers / 2)
    foreach ($q in $data.Papers.Keys) {
        foreach ($p in $data.Papers[$q]) {
            $paperBuffer.Add("$(($paperBuffer.Count + 1)). $($p.Title)")
            $paperBuffer.Add("  저자: $($p.Authors)  |  $($p.Published)")
            if ($p.Summary)   { $paperBuffer.Add("  [원문] $($p.Summary.Substring(0,[Math]::Min(120,$p.Summary.Length)))") }
            if ($p.SummaryKo) { $paperBuffer.Add("  [한글] $($p.SummaryKo.Substring(0,[Math]::Min(120,$p.SummaryKo.Length)))") }
            $paperBuffer.Add("")
            if ($paperBuffer.Count -ge 8) {
                $slides.Add(@{ xml = (New-SlideXml "학술 논문 [$slideNum/$totalPapSl]" $paperBuffer.ToArray() "212F3D") })
                $slideCount++
                $paperBuffer.Clear()
                $slideNum++
            }
        }
    }
    if ($paperBuffer.Count -gt 0) {
        $slides.Add(@{ xml = (New-SlideXml "학술 논문 [$slideNum/$totalPapSl]" $paperBuffer.ToArray() "212F3D") })
        $slideCount++
    }

    # ── AI 분석 슬라이드 ────────────────────────────────────
    if (-not [string]::IsNullOrWhiteSpace($data.Analysis)) {
        $analysisLines = ($data.Analysis -split "`n" | Where-Object { $_.Trim() } | Select-Object -First 18) -replace '^#+\s*', '• '
        $slides.Add(@{ xml = (New-SlideXml "AI 분석 요약 (Claude Opus)" $analysisLines "1A1A2E" "BDD7EE" "FFFFFF") })
        $slideCount++
    }

    # ── Presentation.xml ─────────────────────────────────────
    $sldRefs = for ($i = 1; $i -le $slideCount; $i++) {
        "<p:sldId id=`"$(255 + $i)`" r:id=`"rId$i`"/>"
    }
    $presXml = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>" +
        "<p:presentation xmlns:p=`"http://schemas.openxmlformats.org/presentationml/2006/main`" " +
        "xmlns:a=`"http://schemas.openxmlformats.org/drawingml/2006/main`" " +
        "xmlns:r=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships`" " +
        "saveSubsetFonts=`"1`">" +
        "<p:sldMasterIdLst><p:sldMasterId id=`"2147483648`" r:id=`"rIdM1`"/></p:sldMasterIdLst>" +
        "<p:sldIdLst>$($sldRefs -join '')</p:sldIdLst>" +
        "<p:sldSz cx=`"9144000`" cy=`"5143500`"/><p:notesSz cx=`"6858000`" cy=`"9144000`"/>" +
        "</p:presentation>"

    # ── presentation.xml.rels ────────────────────────────────
    $presRelsList = for ($i = 1; $i -le $slideCount; $i++) {
        "<Relationship Id=`"rId$i`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide`" Target=`"slides/slide$i.xml`"/>"
    }
    $presRelsList += "<Relationship Id=`"rIdM1`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster`" Target=`"slideMasters/slideMaster1.xml`"/>"
    $presRels = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Relationships xmlns=`"http://schemas.openxmlformats.org/package/2006/relationships`">$($presRelsList -join '')</Relationships>"

    # ── slideMaster1 (minimal) ───────────────────────────────
    $master = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>" +
        "<p:sldMaster xmlns:p=`"http://schemas.openxmlformats.org/presentationml/2006/main`" " +
        "xmlns:a=`"http://schemas.openxmlformats.org/drawingml/2006/main`" " +
        "xmlns:r=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships`">" +
        "<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id=`"1`" name=`"Group`"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
        "<p:grpSpPr><a:xfrm><a:off x=`"0`" y=`"0`"/><a:ext cx=`"0`" cy=`"0`"/><a:chOff x=`"0`" y=`"0`"/><a:chExt cx=`"0`" cy=`"0`"/></a:xfrm></p:grpSpPr>" +
        "</p:spTree></p:cSld>" +
        "<p:clrMap bg1=`"lt1`" tx1=`"dk1`" bg2=`"lt2`" tx2=`"dk2`" accent1=`"accent1`" accent2=`"accent2`" accent3=`"accent3`" accent4=`"accent4`" accent5=`"accent5`" accent6=`"accent6`" hlink=`"hlink`" folHlink=`"folHlink`"/>" +
        "<p:sldLayoutIdLst/></p:sldMaster>"
    $masterRels = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Relationships xmlns=`"http://schemas.openxmlformats.org/package/2006/relationships`"></Relationships>"

    # ── Slide rels (each slide has empty rels) ───────────────
    $emptyRels = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Relationships xmlns=`"http://schemas.openxmlformats.org/package/2006/relationships`"></Relationships>"

    # ── Content Types ────────────────────────────────────────
    $slideOverrides = for ($i = 1; $i -le $slideCount; $i++) {
        "<Override PartName=`"/ppt/slides/slide$i.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.presentationml.slide+xml`"/>"
    }
    $ctXml = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Types xmlns=`"http://schemas.openxmlformats.org/package/2006/content-types`"><Default Extension=`"rels`" ContentType=`"application/vnd.openxmlformats-package.relationships+xml`"/><Default Extension=`"xml`" ContentType=`"application/xml`"/><Override PartName=`"/ppt/presentation.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml`"/><Override PartName=`"/ppt/slideMasters/slideMaster1.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml`"/>$($slideOverrides -join '')</Types>"

    $rootRels = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?><Relationships xmlns=`"http://schemas.openxmlformats.org/package/2006/relationships`"><Relationship Id=`"rId1`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument`" Target=`"ppt/presentation.xml`"/></Relationships>"

    # ── Assemble ZIP ─────────────────────────────────────────
    $files = @{
        "[Content_Types].xml"                        = $ctXml
        "_rels/.rels"                                = $rootRels
        "ppt/presentation.xml"                       = $presXml
        "ppt/_rels/presentation.xml.rels"            = $presRels
        "ppt/slideMasters/slideMaster1.xml"          = $master
        "ppt/slideMasters/_rels/slideMaster1.xml.rels" = $masterRels
    }
    for ($i = 1; $i -le $slideCount; $i++) {
        $files["ppt/slides/slide$i.xml"]                    = $slides[$i - 1].xml
        $files["ppt/slides/_rels/slide$i.xml.rels"]         = $emptyRels
    }
    New-ZipDocument -outPath $outPath -files $files
}

# ─────────────────────────────────────────────────────────────
#  HWP 문서 (COM 자동화)
# ─────────────────────────────────────────────────────────────
function Export-Hwp {
    param($data, [string]$outPath)

    # HWP COM 클래스 후보 목록
    $hwpClasses = @(
        "HWPApplication.9",
        "HWPApplication.8",
        "HWPApplication",
        "Hwp.HwpObject",
        "hwpFrame.Application",
        "HncApp.Application"
    )

    $hwp = $null
    foreach ($cls in $hwpClasses) {
        try {
            $hwp = New-Object -ComObject $cls -ErrorAction Stop
            Write-Host "  HWP COM 연결: $cls" -ForegroundColor Green
            break
        } catch { }
    }

    if ($null -eq $hwp) {
        Write-Warning "  HWP COM 자동화 미지원. HTML 파일로 대체 저장합니다."
        Export-HwpAsHtml -data $data -outPath ($outPath -replace '\.hwp$', '_hwp.html')
        return
    }

    try {
        $hwp.XHwpDocuments.Add($true) | Out-Null
        $doc = $hwp.HwpDocuments.Item(0)
        $ctrl = $doc.GetHeadCtrl()

        function HwpHeading([string]$text, [int]$level) {
            $para = $ctrl.CreatePara()
            $para.Style = "제목 $level"
            $run = $para.CreateRun()
            $run.Text = $text
            $para.AddCtrl($run) | Out-Null
            $ctrl.AddCtrl($para) | Out-Null
        }
        function HwpPara([string]$text) {
            $para = $ctrl.CreatePara()
            $run = $para.CreateRun()
            $run.Text = $text
            $para.AddCtrl($run) | Out-Null
            $ctrl.AddCtrl($para) | Out-Null
        }

        HwpHeading "국방 군수 AI 활용 방안 연구 - 일일 리포트" 1
        HwpPara    "생성: $($data.GeneratedAt.ToString('yyyy년 MM월 dd일 HH:mm'))"
        HwpHeading "1. 글로벌 뉴스" 2
        foreach ($kw in $data.GlobalNews.Keys) {
            HwpHeading "검색어: $kw" 3
            $i = 1
            foreach ($a in $data.GlobalNews[$kw]) {
                HwpPara "$i. $($a.Title)"
                HwpPara "출처: $($a.Source)  |  날짜: $($a.Published)"
                if ($a.Summary) { HwpPara "요약: $($a.Summary)" }
                HwpPara "링크: $($a.Link)"
                HwpPara ""
                $i++
            }
        }
        # (국내뉴스, 논문도 동일 패턴)
        $doc.SaveAs($outPath, "HWP") | Out-Null
        Write-Host "  HWP 저장 완료" -ForegroundColor Green
    }
    catch {
        Write-Warning "  HWP 저장 오류: $_"
    }
    finally {
        try { $hwp.Quit() } catch { }
        if ($hwp) { [System.Runtime.InteropServices.Marshal]::ReleaseComObject($hwp) | Out-Null }
    }
}

# HWP COM 실패 시 HTML 대체 저장
function Export-HwpAsHtml {
    param($data, [string]$outPath)

    $d   = $data.GeneratedAt.ToString("yyyy년 MM월 dd일 HH:mm")
    $sb  = [System.Text.StringBuilder]::new()
    $sb.Append("<!DOCTYPE html><html lang=`"ko`"><head><meta charset=`"UTF-8`">") | Out-Null
    $sb.Append("<title>국방 군수 AI 활용 방안 연구 - 일일 리포트</title>") | Out-Null
    $sb.Append("<style>body{font-family:'맑은 고딕',sans-serif;font-size:11pt;margin:40px;color:#222} ") | Out-Null
    $sb.Append("h1{color:#1F3864;border-bottom:2px solid #1F3864;padding-bottom:4px} ") | Out-Null
    $sb.Append("h2{color:#2E74B5} h3{color:#5B9BD5} ") | Out-Null
    $sb.Append(".article{margin-bottom:12px;padding:8px;background:#f5f8ff;border-left:3px solid #2E74B5} ") | Out-Null
    $sb.Append(".label{font-weight:bold} .label.ko{color:#1F5C8B} .ko{color:#1F5C8B} ") | Out-Null
    $sb.Append("table{border-collapse:collapse;width:60%} ") | Out-Null
    $sb.Append("td,th{border:1px solid #ccc;padding:6px 12px}</style></head><body>") | Out-Null
    $sb.Append("<h1>국방 군수 AI 활용 방안 연구</h1><h2>일일 리포트 &middot; $d</h2><hr>") | Out-Null

    function HtmlSection([string]$title) { $sb.Append("<h1>$title</h1>") | Out-Null }
    function HtmlKw([string]$kw)        { $sb.Append("<h2>검색어: $(ConvertTo-XmlText $kw)</h2>") | Out-Null }
    function HtmlArticle([hashtable]$a, [int]$idx) {
        $t     = ConvertTo-XmlText $a.Title
        $src   = ConvertTo-XmlText $a.Source
        $sum   = if ($a['Summary'])   { ConvertTo-XmlText $a['Summary'] }   else { "" }
        $sumKo = if ($a['SummaryKo']) { ConvertTo-XmlText $a['SummaryKo'] } else { "" }
        $lnk   = ConvertTo-XmlText $a.Link
        $sb.Append("<div class=`"article`"><p><b>$idx. $t</b></p>") | Out-Null
        $sb.Append("<p><span class=`"label`">출처:</span> $src &nbsp; <span class=`"label`">날짜:</span> $($a.Published)</p>") | Out-Null
        if ($sum)   { $sb.Append("<p><span class=`"label`">요약 (원문):</span> $sum</p>") | Out-Null }
        if ($sumKo) { $sb.Append("<p><span class=`"label ko`">요약 (한글):</span> <span class=`"ko`">$sumKo</span></p>") | Out-Null }
        $sb.Append("<p><span class=`"label`">링크:</span> <a href=`"$lnk`">$lnk</a></p></div>") | Out-Null
    }

    HtmlSection "1. 글로벌 뉴스 (Global News)"
    foreach ($kw in $data.GlobalNews.Keys) {
        HtmlKw $kw; $i = 1
        foreach ($a in $data.GlobalNews[$kw]) { HtmlArticle $a $i; $i++ }
    }
    HtmlSection "2. 국내 뉴스 (Korean Domestic News)"
    foreach ($kw in $data.KrNews.Keys) {
        HtmlKw $kw; $i = 1
        foreach ($a in $data.KrNews[$kw]) { HtmlArticle $a $i; $i++ }
    }
    HtmlSection "3. 최신 학술 논문 (ArXiv)"
    foreach ($q in $data.Papers.Keys) {
        HtmlKw $q; $i = 1
        foreach ($p in $data.Papers[$q]) {
            $t = ConvertTo-XmlText $p.Title
            $sum = if ($p.Summary) { ConvertTo-XmlText $p.Summary } else { "" }
            $sumKo = if ($p['SummaryKo']) { ConvertTo-XmlText $p['SummaryKo'] } else { "" }
            $sb.Append("<div class=`"article`"><p><b>$i. $t</b></p>") | Out-Null
            $sb.Append("<p><span class=`"label`">저자:</span> $(ConvertTo-XmlText $p.Authors) &nbsp; <span class=`"label`">날짜:</span> $($p.Published)</p>") | Out-Null
            if ($sum)   { $sb.Append("<p><span class=`"label`">초록 (원문):</span> $sum</p>") | Out-Null }
            if ($sumKo) { $sb.Append("<p><span class=`"label ko`">초록 (한글):</span> <span class=`"ko`">$sumKo</span></p>") | Out-Null }
            $sb.Append("<p><span class=`"label`">링크:</span> <a href=`"$($p.Link)`">$($p.Link)</a></p></div>") | Out-Null
            $i++
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($data.Analysis)) {
        HtmlSection "4. AI 분석 요약"
        $sb.Append("<div style=`"background:#f0f4ff;padding:16px;border-radius:4px`">") | Out-Null
        foreach ($line in ($data.Analysis -split "`n")) {
            $l = ConvertTo-XmlText $line.Trim()
            if ($l) { $sb.Append("<p>$l</p>") | Out-Null }
        }
        $sb.Append("</div>") | Out-Null
    }
    HtmlSection "5. 수집 통계"
    $sb.Append("<table><tr><th>항목</th><th>건수</th></tr>") | Out-Null
    $sb.Append("<tr><td>글로벌 뉴스</td><td>$($data.TotalGlobal)건</td></tr>") | Out-Null
    $sb.Append("<tr><td>국내 뉴스</td><td>$($data.TotalKr)건</td></tr>")       | Out-Null
    $sb.Append("<tr><td>학술 논문</td><td>$($data.TotalPapers)건</td></tr>")   | Out-Null
    $sb.Append("</table><br><p>* 본 리포트는 자동 생성되었습니다. 생성: $d</p>") | Out-Null
    $sb.Append("</body></html>") | Out-Null

    $utf8bom = New-Object System.Text.UTF8Encoding $true
    [System.IO.File]::WriteAllText($outPath, $sb.ToString(), $utf8bom)
}

# ─────────────────────────────────────────────────────────────
#  통합 내보내기 함수 (main에서 호출)
# ─────────────────────────────────────────────────────────────
function Export-AllFormats {
    param($data, [string]$baseDir, [string]$baseName)

    # Word
    Write-Host "  [DOCX] 생성 중..." -ForegroundColor Cyan
    try {
        Export-Docx -data $data -outPath (Join-Path $baseDir "$baseName.docx")
        Write-Host "  [DOCX] 완료" -ForegroundColor Green
    } catch { Write-Warning "  [DOCX] 오류: $_" }

    # PowerPoint
    Write-Host "  [PPTX] 생성 중..." -ForegroundColor Cyan
    try {
        Export-Pptx -data $data -outPath (Join-Path $baseDir "$baseName.pptx")
        Write-Host "  [PPTX] 완료" -ForegroundColor Green
    } catch { Write-Warning "  [PPTX] 오류: $_" }

    # HWP
    Write-Host "  [HWP]  생성 중..." -ForegroundColor Cyan
    try {
        Export-Hwp -data $data -outPath (Join-Path $baseDir "$baseName.hwp")
    } catch { Write-Warning "  [HWP] 오류: $_" }
}
