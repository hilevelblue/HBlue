﻿#Requires -Version 5.1
<#
.SYNOPSIS
    국방 군수 AI 활용 방안 연구 - 일일 리포트 자동 생성기
    Daily Report Generator for AI in Defense Logistics Research

.DESCRIPTION
    글로벌/국내 뉴스, ArXiv 학술 논문, Claude AI 분석 요약을 매일 자동 수집하여
    Markdown(.md) / Word(.docx) / PowerPoint(.pptx) / HWP 형식으로 저장합니다.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

# export.ps1 로드
. (Join-Path $PSScriptRoot "export.ps1")

# ─────────────────────────────────────────────
# 설정 로드
# ─────────────────────────────────────────────
$configPath = Join-Path $PSScriptRoot "config.json"
if (-not (Test-Path $configPath)) {
    Write-Error "config.json 파일을 찾을 수 없습니다: $configPath"
    exit 1
}

$config    = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
$reportDir = $config.report_directory
$apiKey    = $config.anthropic_api_key
$maxNews   = $config.max_news_per_keyword
$maxArxiv  = $config.max_arxiv_per_query

if (-not (Test-Path $reportDir)) {
    New-Item -ItemType Directory -Path $reportDir -Force | Out-Null
    Write-Host "  리포트 폴더 생성: $reportDir" -ForegroundColor DarkGray
}

# ─────────────────────────────────────────────
# 유틸리티 함수
# ─────────────────────────────────────────────
function Remove-HtmlTags {
    param([string]$text)
    if ([string]::IsNullOrEmpty($text)) { return "" }
    $text = $text -replace '<[^>]+>', ''
    $text = $text -replace '&amp;',  '&'
    $text = $text -replace '&lt;',   '<'
    $text = $text -replace '&gt;',   '>'
    $text = $text -replace '&quot;', '"'
    $text = $text -replace '&#39;',  "'"
    $text = $text -replace '&nbsp;', ' '
    $text = $text -replace '\s+',    ' '
    return $text.Trim()
}

function Truncate {
    param([string]$text, [int]$maxLen = 300)
    if ([string]::IsNullOrEmpty($text)) { return "" }
    if ($text.Length -le $maxLen) { return $text }
    return $text.Substring(0, $maxLen) + "..."
}

function Translate-ToKorean {
    param([string]$text)
    if ([string]::IsNullOrEmpty($text)) { return "" }
    try {
        $encoded  = [System.Uri]::EscapeDataString($text)
        $url      = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ko&dt=t&q=$encoded"
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
        $json     = $response.Content | ConvertFrom-Json
        # 번역된 세그먼트를 이어붙임
        $result   = ($json[0] | ForEach-Object { if ($_[0]) { $_[0] } }) -join ""
        return $result.Trim()
    }
    catch { return "" }
}

# ─────────────────────────────────────────────
# 검색 함수
# ─────────────────────────────────────────────
function Search-GoogleNewsRSS {
    param(
        [string]$keyword,
        [string]$lang  = "en-US",
        [string]$gl    = "US",
        [string]$ceid  = "US:en",
        [int]   $maxResults = 5
    )
    try {
        $encoded = [System.Uri]::EscapeDataString($keyword)
        $url     = "https://news.google.com/rss/search?q=$encoded&hl=$lang&gl=$gl&ceid=$ceid"
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 20 -ErrorAction Stop
        [xml]$feed = $response.Content

        $articles = @()
        foreach ($item in ($feed.rss.channel.item | Select-Object -First $maxResults)) {
            $articles += @{
                Title     = Remove-HtmlTags $item.title
                Link      = $item.link
                Published = $item.pubDate
                Summary   = Truncate (Remove-HtmlTags $item.description) 280
                Source    = if ($item.source) { $item.source.'#text' } else { "Google News" }
            }
        }
        return $articles
    }
    catch {
        Write-Warning "  [뉴스 검색 실패] $keyword - $_"
        return @()
    }
}

function Search-ArXiv {
    param([string]$query, [int]$maxResults = 5)
    try {
        $encoded  = [System.Uri]::EscapeDataString($query)
        $url      = "https://export.arxiv.org/api/query?search_query=all:$encoded&start=0&max_results=$maxResults&sortBy=submittedDate&sortOrder=descending"
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 25 -ErrorAction Stop
        [xml]$feed = $response.Content

        $papers = @()
        foreach ($entry in $feed.feed.entry) {
            $authors  = @($entry.author | ForEach-Object { $_.name })
            $authorStr = ($authors | Select-Object -First 3) -join ", "
            if ($authors.Count -gt 3) { $authorStr += " 외 $($authors.Count - 3)명" }
            $rawId   = if ($entry.id -is [string]) { $entry.id } else { $entry.id.'#text' }
            $arxivId = ($rawId -split '/') | Select-Object -Last 1
            $papers += @{
                Title     = ($entry.title -replace '\s+', ' ').Trim()
                Authors   = $authorStr
                Published = $entry.published.Substring(0, 10)
                Summary   = Truncate (($entry.summary -replace '\s+', ' ').Trim()) 380
                Link      = "https://arxiv.org/abs/$arxivId"
            }
        }
        return $papers
    }
    catch {
        Write-Warning "  [ArXiv 검색 실패] $query - $_"
        return @()
    }
}

function Invoke-ClaudeAnalysis {
    param([string]$summaryText, [string]$apiKey)
    if ([string]::IsNullOrWhiteSpace($apiKey)) { return "" }

    try {
        $promptText = "당신은 국방 군수 분야 AI 전문 연구 분석가입니다.`n아래는 오늘 수집된 국방 군수 AI 관련 뉴스 헤드라인과 학술 논문 제목 목록입니다.`n`n$summaryText`n`n위 정보를 바탕으로 다음 형식의 분석 요약을 한국어로 작성하세요:`n`n### 주요 트렌드 (3-5가지)`n`n### 핵심 기술 동향`n`n### 주목할 국가 및 기관`n`n### 연구자에게 주는 시사점"

        $body = @{
            model      = "claude-opus-4-6"
            max_tokens = 1800
            messages   = @(@{ role = "user"; content = $promptText })
        } | ConvertTo-Json -Depth 5 -Compress

        $headers = @{
            "x-api-key"         = $apiKey
            "anthropic-version" = "2023-06-01"
            "content-type"      = "application/json"
        }
        $resp = Invoke-RestMethod `
            -Uri     "https://api.anthropic.com/v1/messages" `
            -Method  POST `
            -Headers $headers `
            -Body    ([System.Text.Encoding]::UTF8.GetBytes($body)) `
            -TimeoutSec 90 -ErrorAction Stop

        return $resp.content[0].text
    }
    catch {
        Write-Warning "  [Claude API 오류] $_"
        return ""
    }
}

# ─────────────────────────────────────────────
# 데이터 수집 → $reportData 구조체 반환
# ─────────────────────────────────────────────
function Collect-ReportData {
    $data = @{
        GeneratedAt  = Get-Date
        GlobalNews   = [ordered]@{}
        KrNews       = [ordered]@{}
        Papers       = [ordered]@{}
        Analysis     = ""
        TotalGlobal  = 0
        TotalKr      = 0
        TotalPapers  = 0
    }

    $seenGlobal = [System.Collections.Generic.HashSet[string]]::new()
    $seenKr     = [System.Collections.Generic.HashSet[string]]::new()
    $seenPaper  = [System.Collections.Generic.HashSet[string]]::new()

    # ── 글로벌 뉴스 ─────────────────────────────────────────
    foreach ($kw in $config.keywords_en) {
        Write-Host "  [글로벌] $kw" -ForegroundColor Cyan
        $articles = Search-GoogleNewsRSS -keyword $kw -maxResults $maxNews
        Start-Sleep -Milliseconds 600
        $new = @($articles | Where-Object { $seenGlobal.Add($_['Title']) })
        if ($new.Count -gt 0) {
            $data.GlobalNews[$kw] = $new
            $data.TotalGlobal    += $new.Count
        }
    }

    # ── 국내 뉴스 ────────────────────────────────────────────
    foreach ($kw in $config.keywords_kr) {
        Write-Host "  [국내] $kw" -ForegroundColor Magenta
        $articles = Search-GoogleNewsRSS -keyword $kw -lang "ko" -gl "KR" -ceid "KR:ko" -maxResults $maxNews
        Start-Sleep -Milliseconds 600
        $new = @($articles | Where-Object { $seenKr.Add($_['Title']) })
        if ($new.Count -gt 0) {
            $data.KrNews[$kw] = $new
            $data.TotalKr    += $new.Count
        }
    }

    # ── ArXiv 논문 ───────────────────────────────────────────
    foreach ($q in $config.arxiv_queries) {
        Write-Host "  [ArXiv] $q" -ForegroundColor Yellow
        $papers = Search-ArXiv -query $q -maxResults $maxArxiv
        Start-Sleep -Milliseconds 1000
        $new = @($papers | Where-Object { $seenPaper.Add($_['Title']) })
        if ($new.Count -gt 0) {
            $data.Papers[$q] = $new
            $data.TotalPapers += $new.Count
        }
    }

    # ── Claude AI 분석 ───────────────────────────────────────
    if (-not [string]::IsNullOrWhiteSpace($apiKey)) {
        Write-Host "  [Claude] AI 분석 생성 중..." -ForegroundColor Green
        $sb = [System.Text.StringBuilder]::new()
        $sb.AppendLine("=== 글로벌 뉴스 헤드라인 ===") | Out-Null
        $data.GlobalNews.Values | ForEach-Object { $_ } | Select-Object -First 15 | ForEach-Object { $sb.AppendLine("- $($_['Title'])") | Out-Null }
        $sb.AppendLine("") | Out-Null
        $sb.AppendLine("=== 국내 뉴스 헤드라인 ===") | Out-Null
        $data.KrNews.Values    | ForEach-Object { $_ } | Select-Object -First 10 | ForEach-Object { $sb.AppendLine("- $($_['Title'])") | Out-Null }
        $sb.AppendLine("") | Out-Null
        $sb.AppendLine("=== 학술 논문 제목 ===") | Out-Null
        $data.Papers.Values    | ForEach-Object { $_ } | Select-Object -First 10 | ForEach-Object { $sb.AppendLine("- $($_['Title'])") | Out-Null }
        $data.Analysis = Invoke-ClaudeAnalysis -summaryText $sb.ToString() -apiKey $apiKey
    }

    # ── 영문 요약 → 한글 번역 ────────────────────────────────
    $translateTotal = ($data.GlobalNews.Values | ForEach-Object { $_ } | Where-Object { $_['Summary'] } | Measure-Object).Count +
                      ($data.Papers.Values     | ForEach-Object { $_ } | Where-Object { $_['Summary'] } | Measure-Object).Count
    Write-Host "  [번역] 영문 요약 한글 번역 중... ($($translateTotal)건)" -ForegroundColor White

    foreach ($kw in [string[]]($data.GlobalNews.Keys)) {
        foreach ($a in $data.GlobalNews[$kw]) {
            $a['SummaryKo'] = if ($a['Summary']) { Translate-ToKorean $a['Summary'] } else { "" }
            Start-Sleep -Milliseconds 150
        }
    }
    foreach ($q in [string[]]($data.Papers.Keys)) {
        foreach ($p in $data.Papers[$q]) {
            $p['SummaryKo'] = if ($p['Summary']) { Translate-ToKorean $p['Summary'] } else { "" }
            Start-Sleep -Milliseconds 150
        }
    }
    Write-Host "  [번역] 완료" -ForegroundColor White

    return $data
}

# ─────────────────────────────────────────────
# Markdown 리포트 생성 (기존 형식 유지)
# ─────────────────────────────────────────────
function New-MarkdownReport {
    param($data)

    $now    = $data.GeneratedAt
    $lines  = [System.Collections.Generic.List[string]]::new()

    $lines.Add("# 국방 군수 AI 활용 방안 연구 - 일일 리포트")
    $lines.Add("")
    $lines.Add("> **생성일시:** $($now.ToString('yyyy년 MM월 dd일 HH:mm:ss'))")
    $lines.Add("")
    $lines.Add("---")
    $lines.Add("")

    $lines.Add("## 1. 글로벌 뉴스 (Global News)")
    $lines.Add("")
    foreach ($kw in $data.GlobalNews.Keys) {
        $lines.Add("### 검색어: ``$kw``")
        $lines.Add("")
        $i = 1
        foreach ($a in $data.GlobalNews[$kw]) {
            $lines.Add("**$i. $($a['Title'])**")
            $lines.Add("- 출처: $($a['Source'])")
            $lines.Add("- 게재일: $($a['Published'])")
            if ($a['Summary'])   { $lines.Add("- 요약 (원문): $($a['Summary'])") }
            if ($a['SummaryKo']) { $lines.Add("- 요약 (한글): $($a['SummaryKo'])") }
            $lines.Add("- 링크: $($a['Link'])")
            $lines.Add("")
            $i++
        }
    }

    $lines.Add("---")
    $lines.Add("")
    $lines.Add("## 2. 국내 뉴스 (Korean Domestic News)")
    $lines.Add("")
    foreach ($kw in $data.KrNews.Keys) {
        $lines.Add("### 검색어: ``$kw``")
        $lines.Add("")
        $i = 1
        foreach ($a in $data.KrNews[$kw]) {
            $lines.Add("**$i. $($a['Title'])**")
            $lines.Add("- 출처: $($a['Source'])")
            $lines.Add("- 게재일: $($a['Published'])")
            if ($a['Summary']) { $lines.Add("- 요약: $($a['Summary'])") }
            $lines.Add("- 링크: $($a['Link'])")
            $lines.Add("")
            $i++
        }
    }

    $lines.Add("---")
    $lines.Add("")
    $lines.Add("## 3. 최신 학술 논문 (Academic Papers - ArXiv)")
    $lines.Add("")
    foreach ($q in $data.Papers.Keys) {
        $lines.Add("### 검색어: ``$q``")
        $lines.Add("")
        $i = 1
        foreach ($p in $data.Papers[$q]) {
            $lines.Add("**$i. $($p['Title'])**")
            $lines.Add("- 저자: $($p['Authors'])")
            $lines.Add("- 게재일: $($p['Published'])")
            if ($p['Summary'])   { $lines.Add("- 초록 (원문): $($p['Summary'])") }
            if ($p['SummaryKo']) { $lines.Add("- 초록 (한글): $($p['SummaryKo'])") }
            $lines.Add("- 링크: $($p['Link'])")
            $lines.Add("")
            $i++
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($data.Analysis)) {
        $lines.Add("---")
        $lines.Add("")
        $lines.Add("## 4. AI 분석 요약 (Claude Opus 분석)")
        $lines.Add("")
        $lines.Add($data.Analysis)
        $lines.Add("")
    }

    $lines.Add("---")
    $lines.Add("")
    $lines.Add("## 5. 수집 통계")
    $lines.Add("")
    $lines.Add("| 항목 | 건수 |")
    $lines.Add("|:-----|-----:|")
    $lines.Add("| 글로벌 뉴스 기사 | $($data.TotalGlobal)건 |")
    $lines.Add("| 국내 뉴스 기사 | $($data.TotalKr)건 |")
    $lines.Add("| 학술 논문 | $($data.TotalPapers)건 |")
    $lines.Add("")
    $lines.Add("*본 리포트는 자동 생성되었습니다. 생성: $($now.ToString('yyyy-MM-dd HH:mm:ss'))*")

    return $lines -join "`n"
}

# ─────────────────────────────────────────────
# 메인 실행
# ─────────────────────────────────────────────
Write-Host ""
Write-Host ("=" * 58) -ForegroundColor White
Write-Host "  국방 군수 AI 활용 방안 연구 - 일일 리포트 생성기" -ForegroundColor White
Write-Host "  시작: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
Write-Host ("=" * 58) -ForegroundColor White
Write-Host ""

# 1. 데이터 수집
Write-Host "1단계: 데이터 수집 중..." -ForegroundColor Yellow
$reportData = Collect-ReportData

# 2. 파일 이름 기반
$baseName = "defense_ai_report_$(Get-Date -Format 'yyyyMMdd_HHmmss')"

# 3. Markdown 저장
Write-Host "`n2단계: 문서 생성 중..." -ForegroundColor Yellow
$mdContent = New-MarkdownReport -data $reportData
$mdPath    = Join-Path $reportDir "$baseName.md"
$mdContent | Out-File -FilePath $mdPath -Encoding UTF8 -Force
Write-Host "  [MD]   $mdPath" -ForegroundColor DarkGray

# 4. Word / PowerPoint / HWP 내보내기
Export-AllFormats -data $reportData -baseDir $reportDir -baseName $baseName

Write-Host ""
Write-Host ("=" * 58) -ForegroundColor Green
Write-Host "  완료! 저장 위치: $reportDir" -ForegroundColor Green
Write-Host ("=" * 58) -ForegroundColor Green
Write-Host ""
